from django.contrib import admin
from .models import CitaTatuaje

@admin.register(CitaTatuaje)
class CitaTatuajeAdmin(admin.ModelAdmin):
    list_display = ('nombre_cliente', 'correo', 'telefono', 'fecha_cita', 'creado_en')
    search_fields = ('nombre_cliente', 'correo')
    list_filter = ('fecha_cita', 'creado_en')