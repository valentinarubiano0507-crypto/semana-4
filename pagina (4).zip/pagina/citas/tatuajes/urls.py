from django.urls import path
from . import views

urlpatterns = [   
    path('', views.pedir_cita, name='index'),
    path('lista/', views.lista_citas, name='lista_citas'),
    path('pedir/', views.pedir_cita, name='pedir_cita'),
    path('exito/', views.exito, name='exito'),
    path('editar/<str:documento>/', views.editar_tatuaje, name='editar_tatuaje'),
    path('eliminar/<str:documento>/', views.eliminar_cita, name='eliminar_cita'),
]

