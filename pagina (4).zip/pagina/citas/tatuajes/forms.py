from django import forms
from .models import CitaTatuaje

class CitaTatuajeForm(forms.ModelForm):
    class Meta:
        model = CitaTatuaje
        fields = ['nombre_cliente', 'documento', 'correo', 'telefono', 'descripcion_disegno', 'zona_cuerpo', 'fecha_cita']
        widgets = {
            'nombre_cliente': forms.TextInput(attrs={'class': 'form-control'}),
            'documento': forms.TextInput(attrs={'class': 'form-control'}), 
            'correo': forms.EmailInput(attrs={'class': 'form-control'}),
            'telefono': forms.TextInput(attrs={'class': 'form-control'}),
            'descripcion_disegno': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'zona_cuerpo': forms.TextInput(attrs={'class': 'form-control'}),
            'fecha_cita': forms.DateTimeInput(attrs={'type': 'datetime-local', 'class': 'form-control'}),
        }
