from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import CitaTatuaje
from .forms import CitaTatuajeForm



def pedir_cita(request):
    if request.method == 'POST':
        form = CitaTatuajeForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Cita registrada con éxito')
            return redirect('lista_citas')
    else:
        form = CitaTatuajeForm()
    return render(request, 'tatuajes/pedir_cita.html', {'form': form})



def lista_citas(request):
    citas = CitaTatuaje.objects.all()
    return render(request, 'tatuajes/lista_citas.html', {'citas': citas})



def editar_tatuaje(request, documento):
    cita = get_object_or_404(CitaTatuaje, documento=documento)
    
    if request.method == 'POST':
        form = CitaTatuajeForm(request.POST, instance=cita)
        if form.is_valid():
            form.save()
            messages.success(request, 'Usted editó de manera correcta')
            return redirect('lista_citas')
    else:
        form = CitaTatuajeForm(instance=cita)
        # Opcional: para que no editen el documento si no lo deseas
        form.fields['documento'].disabled = True

    return render(request, 'tatuajes/pedir_cita.html', {'form': form})



def exito(request):
    return render(request, 'tatuajes/exito.html')



def eliminar_cita(request, documento):
    cita = get_object_or_404(CitaTatuaje, documento=documento)
    
    if request.method == 'POST':
        cita.delete()
        messages.success(request, 'Se eliminó la cita correctamente')
        return redirect('lista_citas')
        
    return render(request, 'tatuajes/eliminar_cita.html', {'cita': cita})

