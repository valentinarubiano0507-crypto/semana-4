from django.apps import AppConfig


class TatuajesConfig(AppConfig):
    name = 'tatuajes'
