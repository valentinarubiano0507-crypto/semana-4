from django.db import models

class CitaTatuaje(models.Model):
    nombre_cliente = models.CharField(max_length=100)
    documento = models.CharField(max_length=20, unique=True) 
    correo = models.EmailField()
    telefono = models.CharField(max_length=20)
    descripcion_disegno = models.TextField(help_text="Describe la idea, tamaño aproximado y estilo del tatuaje.")
    zona_cuerpo = models.CharField(max_length=100, help_text="¿En qué parte del cuerpo te lo harás?")
    fecha_cita = models.DateTimeField()
    creado_en = models.DateTimeField(auto_now_add=True)


    def __str__(self):
        return f"{self.nombre_cliente} - {self.fecha_cita.strftime('%d/%m/%Y %H:%M')}"

    
